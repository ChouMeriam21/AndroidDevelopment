package fr.imt_atlantique.myfragmentapp.staticfragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;

import android.os.Bundle;

import fr.imt_atlantique.myfragmentapp.R;

public class MainActivity extends AppCompatActivity implements EditFragment.OnEditNameInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onEditName(String name) {
        Fragment f = getSupportFragmentManager().findFragmentById(R.id.displayFragment);
        ((DisplayFragment) f).getName(name);
    }
}