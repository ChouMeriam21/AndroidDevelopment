package fr.imt_atlantique.myfragmentapp.staticfragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

import fr.imt_atlantique.myfragmentapp.R;


public class EditFragment extends Fragment {

    private EditText nom;
    private Button button;

    private View rootView;

    private ViewGroup vgroup;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_blank, container, false);

        nom = (EditText) rootView.findViewById(R.id.PersonName);
        button = (Button) rootView.findViewById(R.id.button);
        vgroup = rootView.findViewById(R.id.constraintLayout);

        Log.i("onClick1", rootView.findViewById(R.id.constraintLayout).toString());

        Log.i("onCreateView", "ok");
        
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.i("onViewCreated", "ok");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nom.getText().toString();
                Snackbar b1 = Snackbar.make(vgroup, name, Snackbar.LENGTH_SHORT);
                Log.i("snack", String.valueOf(b1));
                b1.show();
                ((MainActivity)getActivity()).onEditName(name);
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        getActivity();
    }

    public interface OnEditNameInterface {

        void onEditName(String name);
    }
}