package fr.imt_atlantique.statiquefragment;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import fr.imt_atlantique.statiquefragment.R;


public class DisplayFragment extends Fragment {

    TextView txtnom;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root = inflater.inflate(R.layout.fragment_display, container, false);

        txtnom = (TextView) root.findViewById(R.id.PersonName);

        return root;

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        getActivity();
    }

    public void getName(String name) {
        txtnom.setText(name);
    }

}